/// aws lambda function 

const request = require("request-promise");

exports.handler = async (event) => {
    var options = {
        uri: 'https://search-galacticlistings-t5gsylsxiuyovdyaa7vwlwldce.us-east-1.es.amazonaws.com/serverdata/_search',
        body: {
            "size": 20,
            "query":{
                "query_string":{
                    "default_field": "fields.address",
                    "query": event['queryStringParameters']['q']
                }
            }
        },
        json: true
    };

    var result = await request(options);

    return{
        "isBase64Encoded": false,
        "statusCode": 200,
        "headers":{
            "Access-Control-Allow-Origin": "*"
        },
        "body": JSON.stringify(results)
    };
};
